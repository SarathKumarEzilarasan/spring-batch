package springbatchdemo.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import springbatchdemo.entity.Profile;
import springbatchdemo.entity.User;

@Repository
public interface UserRepository extends JpaRepository<User, Long> {

    Page<User> findByStatusAndEmailVerified(String status
            , boolean emailVerified, Pageable pageable);
}
