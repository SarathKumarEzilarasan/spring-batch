package springbatchdemo.service;

import org.springframework.batch.core.BatchStatus;
import org.springframework.batch.core.JobExecution;
import org.springframework.batch.core.JobExecutionListener;
import org.springframework.stereotype.Service;

@Service
public class JobCompletionNotificationListener implements JobExecutionListener {
    public void afterJob(JobExecution jobExecution) {
        if (jobExecution.getStatus() == BatchStatus.COMPLETED) {
            System.out.println("Job finished");
        } else {
            System.out.println("Job execution status : " + jobExecution.getStatus());
        }
    }
}
