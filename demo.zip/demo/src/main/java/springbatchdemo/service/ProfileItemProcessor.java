package springbatchdemo.service;

import org.springframework.batch.item.ItemProcessor;
import org.springframework.stereotype.Service;
import springbatchdemo.entity.Profile;
import springbatchdemo.entity.User;
@Service
public class ProfileItemProcessor implements ItemProcessor<User, Profile> {

    @Override
    public Profile process(User user) throws Exception {
        Profile profile = new Profile();
        profile.setUserId(user.getId());
        profile.setFullName(user.getFirstName() + " " + user.getLastName());
        return profile;
    }
}
